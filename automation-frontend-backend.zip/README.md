### automation-mock-service

#### Making a mock service for each and every domain possible.
#### features: 
 
