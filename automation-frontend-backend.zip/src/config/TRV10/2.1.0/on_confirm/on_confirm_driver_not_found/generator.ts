import { SessionData } from "../../../session-types";

export async function onConfirmDriverNotFound(existingPayload: any, sessionData: SessionData) {
  return existingPayload;
} 