import { SessionData } from "../../session-types";

export async function onTrackMultipleStopsGenerator(existingPayload: any,sessionData: SessionData){
    //Need to complete this.
    return existingPayload;
}