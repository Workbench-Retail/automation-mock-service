
import { SessionData } from "../../session-types";

export async function searchMultipleStopsScheduleRentalGenerator(existingPayload: any,sessionData: SessionData){
    return existingPayload;
}