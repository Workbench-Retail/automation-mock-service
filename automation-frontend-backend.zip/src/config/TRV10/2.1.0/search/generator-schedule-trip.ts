
import { SessionData } from "../../session-types";

export async function searchMultipleStopsScheduleTripGenerator(existingPayload: any,sessionData: SessionData){
    return existingPayload;
}